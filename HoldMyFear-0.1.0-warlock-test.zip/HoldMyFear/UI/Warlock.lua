--[[
    UI/Warlock.lua - Controller for the Warlock utilities (Forever only): Healthstone button, Soul
    Shard counter, supply reminders, Demon Armor reminder.

    Independent of Fear tracking: it reads bags, spells and the player's own buffs, runs the pure
    rules in Core/Supplies.lua and Core/Reminders.lua, and drives UI/Utility.lua and
    UI/Reminders.lua. Refreshes are coalesced; anything secure waits for combat to end.
    Never deletes anything by itself: shard cleanup is a right-click that opens Blizzard's own
    delete confirmation for exactly one shard.
]]

local _, HMF = ...

local Warlock = {}
HMF.UI.Warlock = Warlock

local C = HMF.Constants
local K = C.WARLOCK
local S = HMF.Services.Supplies
local R = HMF.Services.Reminders
local A = HMF.Adapters.Warlock
local Unit = HMF.Adapters.Unit
local Utility, Reminders -- UI modules, resolved at Init (they load before this file)

local tracker = R.New()
local pendingActions = false
local refreshQueued = false
local pendingTrade
local started = false
local lastSaid, lastSaidAt = nil, 0

local STONE_FALLBACK = "Interface\\Icons\\INV_Stone_04"
local SHARD_FALLBACK = "Interface\\Icons\\INV_Misc_Gem_Amethyst_02"
local ARMOR_FALLBACK = "Interface\\Icons\\Spell_Shadow_RagingScream"

local function Say(message)
    local t = GetTime()
    if message == lastSaid and t - lastSaidAt < 1 then return end
    lastSaid, lastSaidAt = message, t
    HMF.Debug.Print(message)
end

-- Saved variables: account-wide layout, per-character shard limits (keyed by character GUID).
local function DB()
    HoldMyFearDB.warlock = HoldMyFearDB.warlock or {}
    local w = HoldMyFearDB.warlock
    w.strip, w.reminders, w.chars = w.strip or {}, w.reminders or {}, w.chars or {}
    local guid = UnitGUID("player") or "unknown"
    w.chars[guid] = w.chars[guid] or {}
    return w, w.chars[guid]
end

local function KnowsAny(ids)
    for _, id in ipairs(ids) do
        if A.Known(id) then return true end
    end
    return false
end

-- Name of the best Demon Armor line the player knows, or nil.
local function ArmorName()
    for _, name in ipairs(S.DEMON_ARMOR) do
        if KnowsAny(K.ARMOR_IDS[name]) then return name end
    end
    return nil
end

local function Snapshot()
    local _, char = DB()
    local soulSlots = A.SoulBagSlots()
    local armorName = ArmorName()
    return {
        knowsHealthstone = S.BestKnownRank(A.Known) ~= nil,
        stoneCount = S.StoneCount(A.Carried),
        bestItem = S.BestCarried(A.Carried),
        soulstones = S.CountIn(S.SOULSTONES, A.Carried),
        soulItem = S.BestCarriedIn(S.SOULSTONES, A.Carried),
        soulRank = S.BestKnownIn(S.SOULSTONES, A.Known),
        createRank = S.CreateRank(A.Known, A.Carried),
        shards = A.CountShards(),
        soulBagSlots = soulSlots,
        limit = S.ShardLimit(soulSlots, char.shardLimit),
        minShards = char.minShards or S.DEFAULT_MIN_SHARDS,
        knowsArmor = armorName ~= nil,
        armorName = armorName,
        armor = armorName and A.PlayerBuff(S.DEMON_ARMOR) or nil,
        knowsDrainSoul = KnowsAny(K.DRAIN_SOUL_IDS),
    }
end

-- Reminder view models ------------------------------------------------------------

local function View(r, snap)
    if r.id == "healthstone" then
        local rank = snap.createRank
        local icon = (rank and A.ItemIcon(rank.item)) or STONE_FALLBACK
        return {
            id = r.id, kind = r.kind, icon = icon, label = "No Healthstone",
            action = rank and { type = "spell", spell = rank.spell } or nil,
            tip = rank and { "No Healthstone", "Click to create one." } or { "No Healthstone", "You carry every rank you can make." },
        }
    elseif r.id == "armor" then
        local name = snap.armorName
        return {
            id = r.id, kind = r.kind, icon = A.SpellIcon(name) or ARMOR_FALLBACK,
            label = (r.kind == "missing") and (name .. " missing") or name,
            expires = r.expires, duration = r.duration,
            action = { type = "spell", spell = name },
            tip = { name, r.kind == "missing" and "Your armor buff is down. Click to cast it." or "Running out soon. Click to recast." },
        }
    else
        return {
            id = r.id, kind = r.kind, icon = A.ItemIcon(S.SHARD_ITEM) or SHARD_FALLBACK,
            label = ("Soul Shards %d/%d"):format(r.count or 0, r.minimum or 0),
            action = snap.knowsDrainSoul and { type = "macro", macrotext = "/cast [harm,nodead] Drain Soul" } or nil,
            tip = { "Low on Soul Shards", snap.knowsDrainSoul and "Target an enemy and click to Drain Soul." or "Drain Soul a mob to get more." },
        }
    end
end

-- Refresh -------------------------------------------------------------------------

function Warlock.Refresh()
    if not started then return end
    local snap = Snapshot()

    local cdStart, cdDuration = 0, 0
    if snap.bestItem then cdStart, cdDuration = A.ItemCooldown(snap.bestItem) end
    local soulStart, soulDuration = 0, 0
    if snap.soulItem then soulStart, soulDuration = A.ItemCooldown(snap.soulItem) end
    local m = {
        soulstones = snap.soulstones, soulItem = snap.soulItem, soulRank = snap.soulRank,
        soulIcon = (snap.soulItem and A.ItemIcon(snap.soulItem)) or (snap.soulRank and A.ItemIcon(snap.soulRank.item)) or nil,
        soulCooldownStart = soulStart, soulCooldownDuration = soulDuration,
        stones = snap.stoneCount, bestItem = snap.bestItem, createRank = snap.createRank,
        shards = snap.shards, limit = snap.limit, state = S.ShardState(snap.shards, snap.limit, snap.minShards),
        stoneIcon = (snap.bestItem and A.ItemIcon(snap.bestItem)) or (snap.createRank and A.ItemIcon(snap.createRank.item)) or STONE_FALLBACK,
        shardIcon = A.ItemIcon(S.SHARD_ITEM) or SHARD_FALLBACK,
        cooldownStart = cdStart, cooldownDuration = cdDuration,
    }
    Utility.SetCounts(m)
    if InCombatLockdown() then
        pendingActions = true -- secure actions change after combat
    else
        Utility.Apply(m)
        pendingActions = false
    end

    local active, appeared = tracker:Update(snap, GetTime())
    local views, news = {}, {}
    for _, r in ipairs(active) do views[#views + 1] = View(r, snap) end
    for _, id in ipairs(appeared) do news[id] = true end
    Reminders.Sync(views, news)
end

-- Coalesce bursts of bag/aura events into one refresh.
function Warlock.Request()
    if refreshQueued then return end
    refreshQueued = true
    C_Timer.After(K.REFRESH_DELAY, function()
        refreshQueued = false
        Warlock.Refresh()
    end)
end

-- Healthstone trade (shift-click) ----------------------------------------------------

function Warlock.Trade()
    local name, level = A.FriendlyTarget()
    if not name then
        Say("Target a friendly player, then shift-click to trade them a Healthstone.")
        return
    end
    local item = S.BestCarriedFor(level, A.Carried, function(i) return A.ItemMinLevel(i) or S.LevelOf(i) end)
    if not item then
        Say(S.StoneCount(A.Carried) > 0 and ("None of your Healthstones can be used at " .. name .. "'s level.")
            or "You have no Healthstone to trade. Right-click to create one.")
        return
    end
    pendingTrade = { item = item, name = name, time = GetTime() }
    if not A.InitiateTrade() then
        pendingTrade = nil
        Say("Could not open a trade window.")
    end
end

local function OnTradeShow()
    local trade = pendingTrade
    pendingTrade = nil
    if not trade or GetTime() - trade.time > 15 then return end
    local ok, why = A.PlaceInTrade(trade.item)
    if ok then
        Say("Healthstone is in the trade window. Press Trade to give it.")
    elseif why == "restricted" then
        Say("The game blocks moving items right now (combat or an addon restriction). Drag the Healthstone into the trade window yourself.")
    elseif why ~= "no stone" then
        Say("The game would not let HMF place it. Drag the Healthstone into the trade window yourself.")
    end
end

-- Surplus shard cleanup (right-click on the counter) ---------------------------------------

-- Offers ONE surplus shard to Blizzard's delete confirmation. Never automatic, never without that
-- confirmation, never below the limit.
function Warlock.Trim()
    local _, char = DB()
    local count = A.CountShards()
    local limit = S.ShardLimit(A.SoulBagSlots(), char.shardLimit)
    if S.Surplus(count, limit) <= 0 then
        Say(("Soul Shards %d / %d: nothing over your limit."):format(count, limit))
        return
    end
    local pick = S.PickTrimSlot(A.ShardSlots())
    if not pick then return end
    local ok, why = A.ConfirmDeleteShard(pick.bag, pick.slot)
    if not ok then
        if why == "restricted" then
            Say("The game blocks deleting items right now (combat or an addon restriction). Try again outside combat.")
        else
            Say("Could not pick up the shard (" .. tostring(why) .. ").")
        end
    end
end

-- Settings and commands --------------------------------------------------------------------

-- /hmf shards [limit <n|auto> | min <n>]
function Warlock.ShardsCommand(sub, arg)
    if not started then return "Soul Shard tools are Forever only" end
    local _, char = DB()
    local soul = A.SoulBagSlots()
    if sub == "limit" then
        if arg == "auto" then
            char.shardLimit = nil
        else
            local n = tonumber(arg)
            if not n or n < 1 or n > 100 then return "usage: /hmf shards limit <1-100|auto>" end
            char.shardLimit = math.floor(n)
        end
    elseif sub == "min" then
        local n = tonumber(arg)
        if not n or n < 0 or n > 100 then return "usage: /hmf shards min <0-100>" end
        char.minShards = math.floor(n)
    elseif sub ~= "" and sub ~= nil then
        return "usage: /hmf shards [limit <n|auto> | min <n>]"
    end
    Warlock.Request()
    return ("shards: limit %d (%s), minimum %d"):format(S.ShardLimit(soul, char.shardLimit),
        char.shardLimit and "set" or (soul > 0 and "Soul Bag" or "default"), char.minShards or S.DEFAULT_MIN_SHARDS)
end

function Warlock.SetStripShown(value)
    if not started then return "utility strip is Forever only" end
    if not Utility.SetShown(value) then return "can't change the strip in combat; try again after" end
    return "utility strip " .. (value and "shown" or "hidden")
end

function Warlock.SetLocked(value)
    if not started then return end
    Utility.SetLocked(value)
    Reminders.SetLocked(value)
end

function Warlock.ResetPosition()
    if not started then return end
    Utility.ResetPosition()
    Reminders.ResetPosition()
end

-- /hmf warlock: one screenshot-sized report for in-game verification.
function Warlock.Report()
    if not started then
        HMF.Debug.Print("warlock utilities: off (Forever only, Warlock only)")
        return
    end
    local snap = Snapshot()
    local rank = S.BestKnownRank(A.Known)
    HMF.Debug.Print(("healthstone: knows rank spell %s | carried %d | best item %s | create rank %s"):format(
        rank and rank.spell or "none", snap.stoneCount, tostring(snap.bestItem), snap.createRank and snap.createRank.spell or "none"))
    HMF.Debug.Print(("soulstone: knows rank spell %s | carried %d | best item %s"):format(
        snap.soulRank and snap.soulRank.spell or "none", snap.soulstones, tostring(snap.soulItem)))
    HMF.Debug.Print(("shards: %d / %d (soul bag slots %d, min %d)"):format(snap.shards, snap.limit, snap.soulBagSlots, snap.minShards))
    local armor = snap.armor
    HMF.Debug.Print(("demon armor: %s | buff %s | restricted moves %s | pending actions %s"):format(
        tostring(snap.armorName),
        armor and (armor.readable and (armor.present and ("up" .. (armor.expires and (" " .. math.floor(armor.expires - GetTime()) .. "s") or "")) or "down") or "unreadable") or "n/a",
        tostring(A.MoveRestricted()), tostring(pendingActions)))
end

-- Init -----------------------------------------------------------------------------------

local EVENTS = {
    "PLAYER_ENTERING_WORLD", "BAG_UPDATE_DELAYED", "BAG_UPDATE_COOLDOWN", "PLAYER_REGEN_ENABLED",
    "PLAYER_ALIVE", "PLAYER_UNGHOST", "SPELLS_CHANGED", "TRADE_SHOW", "TRADE_CLOSED",
}

function Warlock.Init()
    if started or not Unit.IsForever() then return end
    Utility, Reminders = HMF.UI.Utility, HMF.UI.Reminders
    local w = DB()
    started = true
    Utility.onTrade, Utility.onTrim = Warlock.Trade, Warlock.Trim
    Utility.SetLocked(HoldMyFearDB.hud == nil or HoldMyFearDB.hud.locked ~= false)
    Reminders.SetLocked(HoldMyFearDB.hud == nil or HoldMyFearDB.hud.locked ~= false)
    Utility.Build(w.strip, Warlock.Request)
    Reminders.Build(w.reminders, Warlock.Request)

    local frame = CreateFrame("Frame")
    for _, event in ipairs(EVENTS) do frame:RegisterEvent(event) end
    frame:RegisterUnitEvent("UNIT_AURA", "player")
    frame:SetScript("OnEvent", function(_, event)
        if event == "TRADE_SHOW" then
            OnTradeShow()
        elseif event == "TRADE_CLOSED" then
            pendingTrade = nil
        else
            Warlock.Request()
        end
    end)

    -- Reminder countdown text; and a slow out-of-combat re-check, because a buff crossing the
    -- 5-minute mark fires no event.
    C_Timer.NewTicker(1, function() Reminders.Tick() end)
    C_Timer.NewTicker(15, function()
        if not InCombatLockdown() then Warlock.Request() end
    end)
    Warlock.Request()
end
