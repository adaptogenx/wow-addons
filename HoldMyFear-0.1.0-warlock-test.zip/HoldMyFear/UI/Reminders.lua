--[[
    UI/Reminders.lua - Contextual supply reminders: missing Healthstone, low Soul Shards,
    Demon Armor missing or expiring. Independent of the Fear HUD and of the utility strip.

    One fixed slot per reminder id. Each slot is a secure button (click performs the fix), so:
      * slots are created once, out of combat;
      * new reminders, attribute changes and layout happen out of combat only;
      * a reminder that resolves in combat is cleared at once by fading it out (alpha is allowed in
        combat) and is hidden for real when combat ends.
    A reminder shows until it is resolved; it pulses once when it first appears, never again for
    the same unresolved state.
]]

local _, HMF = ...

local Reminders = {}
HMF.UI.Reminders = Reminders

local C = HMF.Constants
local K = C.WARLOCK

local WHITE = "Interface\\Buttons\\WHITE8X8"
local TEXCOORD = { 0.07, 0.93, 0.07, 0.93 }
local CELL = 108 -- width of one reminder cell (icon centred, label under it)
local LABEL_H = 30
local IDS = { "healthstone", "armor", "shards" }
local KIND_COLOR = {
    missing = { 1, 0.2, 0.2 },
    expiring = { 1, 0.75, 0.2 },
    low = { 1, 0.75, 0.2 },
}

local container, overlay
local slots = {}
local db
local locked = true

local function SavePosition()
    local point, _, relPoint, x, y = container:GetPoint()
    db.point, db.relPoint, db.x, db.y = point, relPoint, x, y
end

local function MinSec(seconds)
    seconds = math.max(0, math.ceil(seconds))
    return ("%d:%02d"):format(math.floor(seconds / 60), seconds % 60)
end

local function NewSlot(id)
    local b = CreateFrame("Button", nil, container, "SecureActionButtonTemplate,BackdropTemplate")
    b:SetSize(K.SLOT, K.SLOT)
    b:RegisterForClicks("AnyUp")
    b:SetAttribute("useOnKeyDown", false)
    b:SetBackdrop({ edgeFile = WHITE, edgeSize = 2 })
    b:SetBackdropBorderColor(1, 0.2, 0.2, 1)
    b.id = id

    b.icon = b:CreateTexture(nil, "ARTWORK")
    b.icon:SetPoint("TOPLEFT", 2, -2)
    b.icon:SetPoint("BOTTOMRIGHT", -2, 2)
    b.icon:SetTexCoord(unpack(TEXCOORD))

    b.cooldown = CreateFrame("Cooldown", nil, b, "CooldownFrameTemplate")
    b.cooldown:SetAllPoints(b.icon)
    b.cooldown:SetHideCountdownNumbers(true)

    b.glow = b:CreateTexture(nil, "OVERLAY")
    b.glow:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
    b.glow:SetBlendMode("ADD")
    b.glow:SetSize(K.SLOT * 1.8, K.SLOT * 1.8)
    b.glow:SetPoint("CENTER")
    b.glow:SetAlpha(0)
    b.pulse = b.glow:CreateAnimationGroup()
    local up = b.pulse:CreateAnimation("Alpha")
    up:SetFromAlpha(0.1) up:SetToAlpha(1) up:SetDuration(0.4) up:SetOrder(1)
    local down = b.pulse:CreateAnimation("Alpha")
    down:SetFromAlpha(1) down:SetToAlpha(0.1) down:SetDuration(0.4) down:SetOrder(2)
    b.pulse:SetLooping("REPEAT")

    b.label = b:CreateFontString(nil, "OVERLAY")
    b.label:SetFont(STANDARD_TEXT_FONT, 12, "OUTLINE")
    b.label:SetPoint("TOP", b, "BOTTOM", 0, -3)
    b.label:SetWidth(CELL)
    b.label:SetJustifyH("CENTER")

    b:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square", "ADD")
    b:SetScript("OnEnter", function(self)
        if not self.tip then return end
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:SetText(self.tip[1], 1, 1, 1)
        for i = 2, #self.tip do GameTooltip:AddLine(self.tip[i], 0.8, 0.8, 0.8, true) end
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    b:Hide()
    return b
end

local function Create()
    container = CreateFrame("Frame", nil, UIParent)
    container:SetSize(CELL, K.SLOT + LABEL_H)
    container:SetFrameStrata("HIGH")
    container:SetClampedToScreen(true)
    container:SetMovable(true)
    if db.point then
        container:SetPoint(db.point, UIParent, db.relPoint or db.point, db.x or 0, db.y or 0)
    else
        container:SetPoint(K.REMINDER_POINT[1], UIParent, K.REMINDER_POINT[2], K.REMINDER_POINT[3], K.REMINDER_POINT[4])
    end
    for _, id in ipairs(IDS) do slots[id] = NewSlot(id) end

    overlay = CreateFrame("Frame", nil, container)
    overlay:SetAllPoints()
    overlay:SetFrameLevel(container:GetFrameLevel() + 30)
    overlay:EnableMouse(true)
    overlay:RegisterForDrag("LeftButton")
    overlay.bg = overlay:CreateTexture(nil, "OVERLAY")
    overlay.bg:SetAllPoints()
    overlay.bg:SetColorTexture(0.2, 0.8, 0.3, 0.35)
    overlay.text = overlay:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    overlay.text:SetPoint("CENTER")
    overlay.text:SetText("Reminders")
    overlay:SetScript("OnDragStart", function()
        if not InCombatLockdown() then container:StartMoving() end
    end)
    overlay:SetScript("OnDragStop", function()
        container:StopMovingOrSizing()
        SavePosition()
    end)
    overlay:SetShown(not locked)
end

-- Create the slots once, out of combat (waits for combat to end).
function Reminders.Build(savedDB, onBuilt)
    if container then return end
    db = savedDB
    if InCombatLockdown() then
        local waiter = CreateFrame("Frame")
        waiter:RegisterEvent("PLAYER_REGEN_ENABLED")
        waiter:SetScript("OnEvent", function(self)
            self:UnregisterAllEvents()
            Reminders.Build(savedDB, onBuilt)
        end)
        return
    end
    Create()
    if onBuilt then onBuilt() end
end

function Reminders.IsBuilt() return container ~= nil end

-- Out of combat: centre the visible slots in the container.
local function Layout()
    local shown = {}
    for _, id in ipairs(IDS) do
        if slots[id]:IsShown() then shown[#shown + 1] = slots[id] end
    end
    local n = math.max(#shown, 1)
    container:SetSize(n * CELL, K.SLOT + LABEL_H)
    for i, slot in ipairs(shown) do
        slot:ClearAllPoints()
        slot:SetPoint("TOP", container, "TOPLEFT", (i - 0.5) * CELL, 0)
    end
end

local function Fill(slot, r, isNew)
    local color = KIND_COLOR[r.kind] or KIND_COLOR.missing
    slot.tip = r.tip
    slot.expires = (r.kind == "expiring") and r.expires or nil
    slot.icon:SetTexture(r.icon)
    slot:SetBackdropBorderColor(color[1], color[2], color[3], 1)
    slot.glow:SetVertexColor(color[1], color[2], color[3])
    slot.label:SetTextColor(color[1], color[2], color[3])
    slot.label:SetText(slot.expires and (r.label .. "\n" .. MinSec(slot.expires - GetTime())) or r.label)
    if r.kind == "expiring" and r.duration and r.expires then
        slot.cooldown:SetCooldown(r.expires - r.duration, r.duration)
    else
        slot.cooldown:Clear()
    end
    if isNew then
        slot.pulse:Play()
        C_Timer.After(3, function()
            slot.pulse:Stop()
            slot.glow:SetAlpha(0.35) -- stays softly lit while unresolved; no further pulsing
        end)
    end
end

local function SetAction(slot, a)
    slot:SetAttribute("type1", a and a.type or nil)
    slot:SetAttribute("spell1", a and a.spell or nil)
    slot:SetAttribute("macrotext1", a and a.macrotext or nil)
end

-- list: active reminder view models in display order
--   { id, kind, icon, label, expires, duration, tip = {title, lines...}, action = {type, spell, macrotext} }
-- appeared: set of ids that are news. Out of combat everything updates; in combat resolved
-- reminders fade at once and nothing new appears until combat ends.
function Reminders.Sync(list, appeared)
    if not container then return end
    local combat = InCombatLockdown()
    local want = {}
    for _, r in ipairs(list) do want[r.id] = r end

    for _, id in ipairs(IDS) do
        local slot, r = slots[id], want[id]
        if r then
            if not combat then
                SetAction(slot, r.action)
                slot:SetAlpha(1)
                local wasShown = slot:IsShown()
                slot:Show()
                Fill(slot, r, appeared and appeared[id] or not wasShown)
            elseif slot:IsShown() then
                Fill(slot, r, false) -- text only; actions wait for combat to end
                slot:SetAlpha(1)
            end
        elseif slot:IsShown() then
            if combat then
                slot:SetAlpha(0) -- resolved mid-fight: gone now, hidden for real after combat
                slot.expires = nil
            else
                slot:Hide()
                slot.pulse:Stop()
                slot.glow:SetAlpha(0)
                slot.expires = nil
            end
        end
    end
    if not combat then Layout() end
end

-- Once a second: count down an expiring reminder (text only, safe in combat).
function Reminders.Tick()
    for _, id in ipairs(IDS) do
        local slot = slots[id]
        if slot and slot:IsShown() and slot.expires then
            local left = slot.expires - GetTime()
            if left > 0 then
                local text = slot.label:GetText() or ""
                slot.label:SetText((text:match("^[^\n]*")) .. "\n" .. MinSec(left))
            end
        end
    end
end

function Reminders.SetLocked(value)
    locked = value
    if overlay then overlay:SetShown(not value) end
end

function Reminders.ResetPosition()
    if not container or InCombatLockdown() then return false end
    db.point, db.relPoint, db.x, db.y = nil, nil, nil, nil
    container:ClearAllPoints()
    container:SetPoint(K.REMINDER_POINT[1], UIParent, K.REMINDER_POINT[2], K.REMINDER_POINT[3], K.REMINDER_POINT[4])
    return true
end
