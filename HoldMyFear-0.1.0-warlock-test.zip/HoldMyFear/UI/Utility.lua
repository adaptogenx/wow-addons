--[[
    UI/Utility.lua - The small utility strip: Healthstone button + Soul Shard counter.

    Separate from the Fear HUD. The Healthstone button is secure (it works in combat), so:
      * It is created once, out of combat; its actions change only out of combat (the controller
        calls Apply from a safe moment).
      * The strip it is anchored to is protected by that anchoring, so the strip only moves, shows
        or hides out of combat.
    Left-click uses a Healthstone (creates one if you carry none). Right-click creates the best
    rank you can. Shift-click trades one to a friendly player target: its secure action is
    deliberately a no-op, so starting a trade can never use up the stone.
    The shard counter is an ordinary button: right-click offers one surplus shard to Blizzard's own
    delete confirmation. Nothing is ever deleted without that confirmation.
]]

local _, HMF = ...

local Utility = {}
HMF.UI.Utility = Utility

local C = HMF.Constants
local K = C.WARLOCK

local WHITE = "Interface\\Buttons\\WHITE8X8"
local BACKDROP = {
    bgFile = WHITE,
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    edgeSize = 8,
    insets = { left = 2, right = 2, top = 2, bottom = 2 },
}
local EDGE = { edgeFile = WHITE, edgeSize = 1 }
local TEXCOORD = { 0.07, 0.93, 0.07, 0.93 }
local SHARD_FALLBACK = "Interface\\Icons\\INV_Misc_Gem_Amethyst_02"
local STONE_FALLBACK = "Interface\\Icons\\INV_Stone_04"
local SOULSTONE_FALLBACK = "Interface\\Icons\\INV_Misc_Orb_04"

local STATE_COLOR = {
    low = { 1, 0.25, 0.25 },
    over = { 1, 0.75, 0.2 },
    ok = { 1, 1, 1 },
}

local strip, hs, ss, shard, overlay
local db
local locked = true
local model = {} -- last counts, for tooltips

-- Callbacks the controller sets: onTrade() on shift-click, onTrim() on shard right-click.
Utility.onTrade, Utility.onTrim = nil, nil

local function SavePosition()
    local point, _, relPoint, x, y = strip:GetPoint()
    db.point, db.relPoint, db.x, db.y = point, relPoint, x, y
end

local function Tip(owner, build)
    GameTooltip:SetOwner(owner, "ANCHOR_TOP")
    build(GameTooltip)
    GameTooltip:Show()
end

local function StoneTip(tt)
    tt:SetText("Healthstone", 1, 1, 1)
    local m = model
    tt:AddLine(("Carried: %d"):format(m.stones or 0), 0.8, 0.8, 0.8)
    if m.bestItem then
        tt:AddLine("Left-click: use one", 0.6, 1, 0.6)
    elseif m.createRank then
        tt:AddLine("Left-click: create one", 0.6, 1, 0.6)
    else
        tt:AddLine("No Healthstone, and none to create", 1, 0.5, 0.5)
    end
    tt:AddLine(m.createRank and "Right-click: create the best rank you can" or "Right-click: nothing to create", 0.8, 0.8, 0.8)
    tt:AddLine("Shift-click: trade one to a friendly player target", 0.8, 0.8, 0.8)
end

local function SoulstoneTip(tt)
    local m = model
    tt:SetText("Soulstone", 1, 1, 1)
    tt:AddLine(("Carried: %d"):format(m.soulstones or 0), 0.8, 0.8, 0.8)
    if m.soulItem then
        tt:AddLine("Left-click: use on your friendly target, else on yourself", 0.6, 1, 0.6)
    elseif m.soulRank then
        tt:AddLine("Left-click: create one", 0.6, 1, 0.6)
    else
        tt:AddLine("No Soulstone, and none to create", 1, 0.5, 0.5)
    end
    tt:AddLine(m.soulRank and "Right-click: create the best rank you know" or "Right-click: nothing to create", 0.8, 0.8, 0.8)
    tt:AddLine("Can't be applied in combat.", 0.6, 0.6, 0.6)
end

local function ShardTip(tt)
    local m = model
    tt:SetText(("Soul Shards %d / %d"):format(m.shards or 0, m.limit or 0), 1, 1, 1)
    if m.state == "low" then
        tt:AddLine("Below your minimum. Drain Soul a mob.", 1, 0.4, 0.4, true)
    elseif m.state == "over" then
        local extra = (m.shards or 0) - (m.limit or 0)
        tt:AddLine(("%d over your limit. Right-click to delete one (you confirm each)."):format(extra), 1, 0.75, 0.2, true)
    end
    tt:AddLine("Limit: your Soul Bag size, or 6. /hmf shards limit <n> changes it.", 0.6, 0.6, 0.6, true)
end

local function NewStone(index, fallback, tip)
    local b = CreateFrame("Button", nil, strip, "SecureActionButtonTemplate")
    b:SetSize(K.BUTTON, K.BUTTON)
    b:SetPoint("TOPLEFT", strip, "TOPLEFT", K.PAD + (index - 1) * (K.BUTTON + K.GAP), -K.PAD)
    b:RegisterForClicks("AnyUp")
    b:SetAttribute("useOnKeyDown", false)
    b.fallback = fallback

    b.border = CreateFrame("Frame", nil, b, "BackdropTemplate")
    b.border:SetAllPoints()
    b.border:SetBackdrop(EDGE)
    b.border:SetBackdropBorderColor(0.3, 0.3, 0.3, 1)
    b.icon = b:CreateTexture(nil, "ARTWORK")
    b.icon:SetPoint("TOPLEFT", 1, -1)
    b.icon:SetPoint("BOTTOMRIGHT", -1, 1)
    b.icon:SetTexCoord(unpack(TEXCOORD))
    b.icon:SetTexture(fallback)
    b.cooldown = CreateFrame("Cooldown", nil, b, "CooldownFrameTemplate")
    b.cooldown:SetAllPoints(b.icon)
    b.count = b:CreateFontString(nil, "OVERLAY")
    b.count:SetFont(STANDARD_TEXT_FONT, 13, "OUTLINE")
    b.count:SetPoint("BOTTOMRIGHT", -2, 2)
    b:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square", "ADD")

    b:SetScript("OnEnter", function(self) Tip(self, tip) end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    return b
end

local function NewHealthstone()
    local b = NewStone(1, STONE_FALLBACK, StoneTip)
    -- Shift-click must not use the stone: an unknown action type does nothing.
    b:SetAttribute("shift-type1", "hmfnone")
    b:HookScript("PostClick", function(_, mouseButton)
        if mouseButton == "LeftButton" and IsShiftKeyDown() and Utility.onTrade then Utility.onTrade() end
    end)
    return b
end

local function NewSoulstone()
    return NewStone(2, SOULSTONE_FALLBACK, SoulstoneTip)
end

local function NewShard()
    local b = CreateFrame("Button", nil, strip, "BackdropTemplate")
    b:SetSize(K.BUTTON, K.BUTTON)
    b:SetPoint("TOPLEFT", strip, "TOPLEFT", K.PAD + 2 * (K.BUTTON + K.GAP), -K.PAD)
    b:RegisterForClicks("RightButtonUp")
    b:SetBackdrop(EDGE)
    b:SetBackdropBorderColor(0.3, 0.3, 0.3, 1)
    b.icon = b:CreateTexture(nil, "ARTWORK")
    b.icon:SetPoint("TOPLEFT", 1, -1)
    b.icon:SetPoint("BOTTOMRIGHT", -1, 1)
    b.icon:SetTexCoord(unpack(TEXCOORD))
    b.icon:SetTexture(SHARD_FALLBACK)
    -- "4/6" sits on the icon, so the button is self-contained and the same size as the stones.
    b.text = b:CreateFontString(nil, "OVERLAY")
    b.text:SetFont(STANDARD_TEXT_FONT, 12, "OUTLINE")
    b.text:SetPoint("BOTTOM", b, "BOTTOM", 0, 2)
    b.text:SetJustifyH("CENTER")
    b:SetScript("OnEnter", function(self) Tip(self, ShardTip) end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    b:SetScript("OnClick", function() if Utility.onTrim then Utility.onTrim() end end)
    return b
end

local function Create()
    strip = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
    local width = K.PAD * 2 + K.BUTTON * 3 + K.GAP * 2
    strip:SetSize(width, K.BUTTON + K.PAD * 2)
    strip:SetFrameStrata("MEDIUM")
    strip:SetClampedToScreen(true)
    strip:SetMovable(true)
    strip:SetBackdrop(BACKDROP)
    strip:SetBackdropColor(0.04, 0.04, 0.05, 0.8)
    strip:SetBackdropBorderColor(0.4, 0.4, 0.4, 1)
    if db.point then
        strip:SetPoint(db.point, UIParent, db.relPoint or db.point, db.x or 0, db.y or 0)
    else
        strip:SetPoint(K.STRIP_POINT[1], UIParent, K.STRIP_POINT[2], K.STRIP_POINT[3], K.STRIP_POINT[4])
    end

    hs = NewHealthstone()
    ss = NewSoulstone()
    shard = NewShard()

    -- Drag handle, shown only while unlocked (/hmf unlock).
    overlay = CreateFrame("Frame", nil, strip)
    overlay:SetAllPoints()
    overlay:SetFrameLevel(strip:GetFrameLevel() + 20)
    overlay:EnableMouse(true)
    overlay:RegisterForDrag("LeftButton")
    overlay.bg = overlay:CreateTexture(nil, "OVERLAY")
    overlay.bg:SetAllPoints()
    overlay.bg:SetColorTexture(0.2, 0.8, 0.3, 0.35)
    overlay:SetScript("OnDragStart", function()
        if not InCombatLockdown() then strip:StartMoving() end
    end)
    overlay:SetScript("OnDragStop", function()
        strip:StopMovingOrSizing()
        SavePosition()
    end)
    overlay:SetShown(not locked)
end

-- Create the strip once, out of combat (waits for combat to end). db: saved-variables table.
function Utility.Build(savedDB, onBuilt)
    if strip then return end
    db = savedDB
    if InCombatLockdown() then
        local waiter = CreateFrame("Frame")
        waiter:RegisterEvent("PLAYER_REGEN_ENABLED")
        waiter:SetScript("OnEvent", function(self)
            self:UnregisterAllEvents()
            Utility.Build(savedDB, onBuilt)
        end)
        return
    end
    Create()
    strip:SetShown(db.shown ~= false)
    if onBuilt then onBuilt() end
end

function Utility.IsBuilt() return strip ~= nil end

-- Out of combat only: point the Healthstone button's secure actions at what you carry and know.
-- m = { bestItem, createRank, soulItem, soulRank }
function Utility.Apply(m)
    if not hs or InCombatLockdown() then return false end
    local create = m.createRank
    if m.bestItem then
        hs:SetAttribute("type1", "item")
        hs:SetAttribute("item1", "item:" .. m.bestItem)
        hs:SetAttribute("spell1", nil)
    elseif create then
        hs:SetAttribute("type1", "spell")
        hs:SetAttribute("spell1", create.spell)
        hs:SetAttribute("item1", nil)
    else
        hs:SetAttribute("type1", nil)
        hs:SetAttribute("spell1", nil)
        hs:SetAttribute("item1", nil)
    end
    hs:SetAttribute("type2", create and "spell" or nil)
    hs:SetAttribute("spell2", create and create.spell or nil)

    -- Soulstone: use on a friendly target, else on yourself (macro), else create; right-click creates.
    local soulCreate = m.soulRank
    if m.soulItem then
        ss:SetAttribute("type1", "macro")
        ss:SetAttribute("macrotext1", "/use [@target,help,nodead][@player] item:" .. m.soulItem)
        ss:SetAttribute("spell1", nil)
    elseif soulCreate then
        ss:SetAttribute("type1", "spell")
        ss:SetAttribute("spell1", soulCreate.spell)
        ss:SetAttribute("macrotext1", nil)
    else
        ss:SetAttribute("type1", nil)
        ss:SetAttribute("spell1", nil)
        ss:SetAttribute("macrotext1", nil)
    end
    ss:SetAttribute("type2", soulCreate and "spell" or nil)
    ss:SetAttribute("spell2", soulCreate and soulCreate.spell or nil)
    return true
end

-- Safe any time (plain textures and text). m = { stones, bestItem, createRank, shards, limit, state, stoneIcon, shardIcon }
function Utility.SetCounts(m)
    model = m
    if not hs then return end
    hs.icon:SetTexture(m.stoneIcon or STONE_FALLBACK)
    hs.icon:SetDesaturated(not (m.bestItem or m.createRank))
    hs.count:SetText(m.stones or 0)
    hs.count:SetTextColor(unpack((m.stones or 0) > 0 and STATE_COLOR.ok or STATE_COLOR.low))
    if m.cooldownStart and m.cooldownDuration and m.cooldownDuration > 1.5 then
        hs.cooldown:SetCooldown(m.cooldownStart, m.cooldownDuration)
    else
        hs.cooldown:Clear()
    end
    ss.icon:SetTexture(m.soulIcon or SOULSTONE_FALLBACK)
    ss.icon:SetDesaturated(not (m.soulItem or m.soulRank))
    ss.count:SetText(m.soulstones or 0)
    ss.count:SetTextColor(unpack((m.soulstones or 0) > 0 and STATE_COLOR.ok or STATE_COLOR.low))
    if m.soulCooldownStart and m.soulCooldownDuration and m.soulCooldownDuration > 1.5 then
        ss.cooldown:SetCooldown(m.soulCooldownStart, m.soulCooldownDuration)
    else
        ss.cooldown:Clear()
    end
    shard.icon:SetTexture(m.shardIcon or SHARD_FALLBACK)
    shard.text:SetText(("%d/%d"):format(m.shards or 0, m.limit or 0))
    local c = STATE_COLOR[m.state or "ok"]
    shard.text:SetTextColor(c[1], c[2], c[3])
    if m.state == "ok" then
        shard:SetBackdropBorderColor(0.3, 0.3, 0.3, 1)
    else
        shard:SetBackdropBorderColor(c[1], c[2], c[3], 1)
    end
end

function Utility.SetLocked(value)
    locked = value
    if overlay then overlay:SetShown(not value) end
end

-- Out of combat only: the strip is protected by the secure button anchored to it.
function Utility.SetShown(value)
    if db then db.shown = value end
    if not strip or InCombatLockdown() then return false end
    strip:SetShown(value)
    return true
end

function Utility.ResetPosition()
    if not strip or InCombatLockdown() then return false end
    db.point, db.relPoint, db.x, db.y = nil, nil, nil, nil
    strip:ClearAllPoints()
    strip:SetPoint(K.STRIP_POINT[1], UIParent, K.STRIP_POINT[2], K.STRIP_POINT[3], K.STRIP_POINT[4])
    return true
end
