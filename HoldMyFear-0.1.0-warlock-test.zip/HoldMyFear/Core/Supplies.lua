--[[
    Core/Supplies.lua - Warlock supply rules: Healthstone ranks, Soul Shard limit and state.

    Pure logic, no frames and no Blizzard calls: every function takes the facts it needs
    (known(spellID) -> bool, carried(itemID) -> count) so it runs offline in tests.
    Ids are Classic's, as confirmed in the Forever client by Warlock Tools Forever's own data.
]]

local _, HMF = ...

local Supplies = {}
HMF.Services.Supplies = Supplies

-- Create spell and the item it makes, lowest rank first.
Supplies.HEALTHSTONES = {
    { spell = 6201,  item = 5512, level = 1 },  -- Minor
    { spell = 6202,  item = 5511, level = 12 }, -- Lesser
    { spell = 5699,  item = 5509, level = 24 }, -- Healthstone
    { spell = 11729, item = 5510, level = 36 }, -- Greater
    { spell = 11730, item = 9421, level = 48 }, -- Major
}

-- Soulstone ranks, lowest first (same ids Warlock Tools Forever reads in the Forever client).
Supplies.SOULSTONES = {
    { spell = 693,   item = 5232 },  -- Minor
    { spell = 20752, item = 16892 }, -- Lesser
    { spell = 20755, item = 16893 }, -- Soulstone
    { spell = 20756, item = 16895 }, -- Greater
    { spell = 20757, item = 16896 }, -- Major
}

Supplies.SHARD_ITEM = 6265
Supplies.DEFAULT_SHARD_LIMIT = 6 -- without a Soul Bag
Supplies.DEFAULT_MIN_SHARDS = 2

-- Best first; "Demon Armor" replaces Demon Skin once learned.
Supplies.DEMON_ARMOR = { "Demon Armor", "Demon Skin" }

-- Generic over a rank list (Healthstones, Soulstones): count carried, best carried item, best known rank.
function Supplies.CountIn(list, carried)
    local total = 0
    for _, rank in ipairs(list) do total = total + (carried(rank.item) or 0) end
    return total
end

function Supplies.BestCarriedIn(list, carried)
    for i = #list, 1, -1 do
        if (carried(list[i].item) or 0) > 0 then return list[i].item end
    end
    return nil
end

function Supplies.BestKnownIn(list, known)
    for i = #list, 1, -1 do
        if known(list[i].spell) then return list[i] end
    end
    return nil
end

-- Healthstones carried, all ranks.
function Supplies.StoneCount(carried) return Supplies.CountIn(Supplies.HEALTHSTONES, carried) end

-- Item id of the best Healthstone carried, or nil.
function Supplies.BestCarried(carried) return Supplies.BestCarriedIn(Supplies.HEALTHSTONES, carried) end

-- Level a Healthstone needs (built-in, for when the client has not cached item data yet), or nil.
function Supplies.LevelOf(item)
    for _, rank in ipairs(Supplies.HEALTHSTONES) do
        if rank.item == item then return rank.level end
    end
    return nil
end

-- Best carried Healthstone a player of `level` can use (minLevel(item) -> number or nil).
function Supplies.BestCarriedFor(level, carried, minLevel)
    for i = #Supplies.HEALTHSTONES, 1, -1 do
        local item = Supplies.HEALTHSTONES[i].item
        local required = minLevel(item)
        if (carried(item) or 0) > 0 and type(required) == "number" and required <= level then return item end
    end
    return nil
end

-- Highest rank whose create spell the player knows, or nil.
function Supplies.BestKnownRank(known) return Supplies.BestKnownIn(Supplies.HEALTHSTONES, known) end

-- Rank to create: the highest known rank not already carried (each rank is unique in the bags on
-- Forever, so a rank you hold is skipped for the one below). nil when you carry every rank you know.
function Supplies.CreateRank(known, carried)
    for i = #Supplies.HEALTHSTONES, 1, -1 do
        local rank = Supplies.HEALTHSTONES[i]
        if known(rank.spell) and (carried(rank.item) or 0) == 0 then return rank end
    end
    return nil
end

-- limit: the saved setting if any, else the Soul Bag capacity, else 6.
function Supplies.ShardLimit(soulBagSlots, setting)
    if type(setting) == "number" and setting > 0 then return setting end
    if type(soulBagSlots) == "number" and soulBagSlots > 0 then return soulBagSlots end
    return Supplies.DEFAULT_SHARD_LIMIT
end

-- "low" below the minimum, "over" above the limit, else "ok".
function Supplies.ShardState(count, limit, minimum)
    if count < minimum then return "low" end
    if count > limit then return "over" end
    return "ok"
end

function Supplies.Surplus(count, limit)
    return math.max(0, count - limit)
end

-- Which shard to offer for deletion: regular bags before Soul Bags (Soul Bag space is reserved for
-- shards), then the last slot. slots = { { bag, slot, soul }, ... }. nil when there are none.
function Supplies.PickTrimSlot(slots)
    local best
    for _, s in ipairs(slots) do
        if not best then
            best = s
        else
            local sSoul, bSoul = s.soul and 1 or 0, best.soul and 1 or 0
            if sSoul < bSoul or (sSoul == bSoul and (s.bag > best.bag or (s.bag == best.bag and s.slot > best.slot))) then
                best = s
            end
        end
    end
    return best
end
