--[[
    Core/Reminders.lua - Which supply reminders are active, and when one is news.

    Pure state machine. Update(snapshot, t) returns the active reminders in display order plus
    which ones just appeared (a new reminder, or a changed kind) and which were just resolved, so
    the UI draws attention once per unresolved state instead of on every refresh.

    snapshot = {
        knowsHealthstone, stoneCount,
        shards, minShards,
        knowsArmor, armor = { readable, present, expires, duration },
    }
    Reminders: { id = "healthstone", kind = "missing" }
               { id = "armor", kind = "missing" | "expiring", expires, duration }
               { id = "shards", kind = "low", count, minimum }
]]

local _, HMF = ...

local Reminders = {}
HMF.Services.Reminders = Reminders

Reminders.ARMOR_WARN = 300 -- seconds left that count as "expiring"

local ORDER = { "healthstone", "armor", "shards" }

-- "missing" | "expiring" | "ok" | "unknown" (buff unreadable, e.g. in combat) | nil (spell not known).
function Reminders.ArmorState(knowsArmor, armor, t)
    if not knowsArmor then return nil end
    if not armor or not armor.readable then return "unknown" end
    if not armor.present then return "missing" end
    if armor.expires and armor.expires - t <= Reminders.ARMOR_WARN then return "expiring" end
    return "ok"
end

local Tracker = {}
Tracker.__index = Tracker

function Reminders.New()
    return setmetatable({ last = {} }, Tracker)
end

local function build(self, snap, t)
    local found = {}
    if snap.knowsHealthstone and (snap.stoneCount or 0) == 0 then
        found.healthstone = { id = "healthstone", kind = "missing" }
    end
    local state = Reminders.ArmorState(snap.knowsArmor, snap.armor, t)
    if state == "missing" then
        found.armor = { id = "armor", kind = "missing" }
    elseif state == "expiring" then
        found.armor = { id = "armor", kind = "expiring", expires = snap.armor.expires, duration = snap.armor.duration }
    elseif state == "unknown" then
        found.armor = self.last.armor -- cannot read the buff: keep what we knew
    end
    if (snap.shards or 0) < (snap.minShards or 0) then
        found.shards = { id = "shards", kind = "low", count = snap.shards, minimum = snap.minShards }
    end
    return found
end

-- Returns active (array in display order), appeared (array of ids), cleared (array of ids).
function Tracker:Update(snap, t)
    local found = build(self, snap, t)
    local active, appeared, cleared = {}, {}, {}
    for _, id in ipairs(ORDER) do
        local now, before = found[id], self.last[id]
        if now then
            active[#active + 1] = now
            if not before or before.kind ~= now.kind then appeared[#appeared + 1] = id end
        elseif before then
            cleared[#cleared + 1] = id
        end
    end
    self.last = found
    return active, appeared, cleared
end

function Tracker:Reset()
    self.last = {}
end
