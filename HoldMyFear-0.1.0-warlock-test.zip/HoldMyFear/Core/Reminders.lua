--[[
    Core/Reminders.lua - Which supply reminders are active, and when one is news.

    Pure state machine. Update(snapshot, t) returns the active reminders in display order plus
    which ones just appeared (a new reminder, or a changed kind) and which were just resolved, so
    the UI draws attention once per unresolved state instead of on every refresh.

    snapshot = {
        knowsHealthstone, stoneCount,
        shards, minShards,
        knowsArmor, armor = { readable, present, expires, duration },
        knowsSoulstone, soulBuff = { readable, present, expires, duration },
    }
    Reminders: { id = "healthstone", kind = "missing" }
               { id = "armor" | "soulstone", kind = "missing" | "expiring", expires, duration }
               { id = "shards", kind = "low", count, minimum }
]]

local _, HMF = ...

local Reminders = {}
HMF.Services.Reminders = Reminders

Reminders.ARMOR_WARN = 300 -- seconds left that count as "expiring"

local ORDER = { "healthstone", "armor", "soulstone", "shards" }

-- A buff you keep up on yourself (Demon Armor, Soulstone):
-- "missing" | "expiring" | "ok" | "unknown" (buff unreadable, e.g. in combat) | nil (not applicable).
function Reminders.BuffState(applicable, aura, t)
    if not applicable then return nil end
    if not aura or not aura.readable then return "unknown" end
    if not aura.present then return "missing" end
    if aura.expires and aura.expires - t <= Reminders.ARMOR_WARN then return "expiring" end
    return "ok"
end
Reminders.ArmorState = Reminders.BuffState

local Tracker = {}
Tracker.__index = Tracker

function Reminders.New()
    return setmetatable({ last = {} }, Tracker)
end

local function build(self, snap, t)
    local found = {}
    if snap.knowsHealthstone and (snap.stoneCount or 0) == 0 then
        found.healthstone = { id = "healthstone", kind = "missing" }
    end
    local function buff(id, applicable, aura)
        local state = Reminders.BuffState(applicable, aura, t)
        if state == "missing" then
            found[id] = { id = id, kind = "missing" }
        elseif state == "expiring" then
            found[id] = { id = id, kind = "expiring", expires = aura.expires, duration = aura.duration }
        elseif state == "unknown" then
            found[id] = self.last[id] -- cannot read the buff: keep what we knew
        end
    end
    buff("armor", snap.knowsArmor, snap.armor)
    buff("soulstone", snap.knowsSoulstone, snap.soulBuff)
    if (snap.shards or 0) < (snap.minShards or 0) then
        found.shards = { id = "shards", kind = "low", count = snap.shards, minimum = snap.minShards }
    end
    return found
end

-- Returns active (array in display order), appeared (array of ids), cleared (array of ids).
function Tracker:Update(snap, t)
    local found = build(self, snap, t)
    local active, appeared, cleared = {}, {}, {}
    for _, id in ipairs(ORDER) do
        local now, before = found[id], self.last[id]
        if now then
            active[#active + 1] = now
            if not before or before.kind ~= now.kind then appeared[#appeared + 1] = id end
        elseif before then
            cleared[#cleared + 1] = id
        end
    end
    self.last = found
    return active, appeared, cleared
end

function Tracker:Reset()
    self.last = {}
end
