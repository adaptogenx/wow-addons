--[[
    Adapters/WarlockAPI.lua - Blizzard calls behind the Warlock utilities (Healthstone, Soul
    Shards, Demon Armor). The only file that touches inventory, player auras, trade and item
    deletion for them.

    Forever rules honoured here (docs: .plans/FOREVER.md, .plans/WARLOCK_UTILITIES.md):
      * Reads are pcall-guarded and secret-checked; an unreadable value is "unknown", never a guess.
      * Item moves and deletion are refused in combat and under some AddOn restrictions, so every
        mover checks MoveRestricted() first and says what to do by hand instead.
      * Deleting goes through Blizzard's own delete confirmation (DeleteCursorItem is protected).
]]

local _, HMF = ...

local Warlock = {}
HMF.Adapters.Warlock = Warlock

local Unit = HMF.Adapters.Unit

local function isSecret(v) return Unit.IsSecret(v) end

local function number(v)
    if v == nil or isSecret(v) or type(v) ~= "number" then return nil end
    return v
end

-- Spell ---------------------------------------------------------------------

function Warlock.Known(spellID)
    if IsPlayerSpell then
        local ok, known = pcall(IsPlayerSpell, spellID)
        if ok and not isSecret(known) then return known == true end
    end
    if C_SpellBook and C_SpellBook.IsSpellKnown then
        local ok, known = pcall(C_SpellBook.IsSpellKnown, spellID)
        return ok and not isSecret(known) and known == true
    end
    return false
end

-- Icon of a spell by id or name, or nil.
function Warlock.SpellIcon(spell)
    if C_Spell and C_Spell.GetSpellTexture then
        local ok, tex = pcall(C_Spell.GetSpellTexture, spell)
        if ok and not isSecret(tex) then return tex end
    end
    return nil
end

-- Items ---------------------------------------------------------------------

function Warlock.Carried(itemID)
    local getCount = (C_Item and C_Item.GetItemCount) or GetItemCount
    if not getCount then return 0 end
    local ok, count = pcall(getCount, itemID)
    return (ok and number(count)) or 0
end

function Warlock.ItemIcon(itemID)
    local getIcon = (C_Item and C_Item.GetItemIconByID) or GetItemIcon
    if not getIcon then return nil end
    local ok, tex = pcall(getIcon, itemID)
    if ok and not isSecret(tex) then return tex end
    return nil
end

-- Level an item needs, or nil until the client has the item's data.
function Warlock.ItemMinLevel(itemID)
    local getInfo = (C_Item and C_Item.GetItemInfo) or GetItemInfo
    if not getInfo then return nil end
    local ok, _, _, _, _, minLevel = pcall(getInfo, itemID)
    return ok and number(minLevel) or nil
end

-- Remaining cooldown of an item: start, duration (0, 0 when ready or unreadable).
function Warlock.ItemCooldown(itemID)
    local get = (C_Container and C_Container.GetItemCooldown) or GetItemCooldown
    if not get then return 0, 0 end
    local ok, start, duration = pcall(get, itemID)
    if not ok then return 0, 0 end
    return number(start) or 0, number(duration) or 0
end

-- Remaining cooldown of a spell: start, duration (0, 0 when ready or unreadable).
function Warlock.SpellCooldown(spellID)
    if C_Spell and C_Spell.GetSpellCooldown then
        local ok, info = pcall(C_Spell.GetSpellCooldown, spellID)
        if ok and type(info) == "table" then return number(info.startTime) or 0, number(info.duration) or 0 end
        return 0, 0
    end
    if GetSpellCooldown then
        local ok, start, duration = pcall(GetSpellCooldown, spellID)
        if ok then return number(start) or 0, number(duration) or 0 end
    end
    return 0, 0
end

-- Bags -----------------------------------------------------------------------

local SOUL_BAG_FAMILY = 4 -- bit in a bag's family mask
local function lastBag()
    return (type(NUM_TOTAL_EQUIPPED_BAG_SLOTS) == "number" and NUM_TOTAL_EQUIPPED_BAG_SLOTS)
        or (type(NUM_BAG_SLOTS) == "number" and NUM_BAG_SLOTS) or 4
end

local function isSoulBag(bag)
    if bag == 0 then return false end
    local ok, _, family = pcall(C_Container.GetContainerNumFreeSlots, bag)
    family = ok and number(family)
    return family and math.floor(family / SOUL_BAG_FAMILY) % 2 == 1 or false
end

-- Total slots in carried Soul Bags (0 without one).
function Warlock.SoulBagSlots()
    if not (C_Container and C_Container.GetContainerNumSlots) then return 0 end
    local total = 0
    for bag = 1, lastBag() do
        if isSoulBag(bag) then
            local ok, slots = pcall(C_Container.GetContainerNumSlots, bag)
            total = total + ((ok and number(slots)) or 0)
        end
    end
    return total
end

-- Every Soul Shard stack: { bag, slot, soul, count }.
function Warlock.ShardSlots()
    local list = {}
    if not (C_Container and C_Container.GetContainerNumSlots and C_Container.GetContainerItemInfo) then return list end
    local shard = HMF.Services.Supplies.SHARD_ITEM
    for bag = 0, lastBag() do
        local soul = isSoulBag(bag)
        local okN, slots = pcall(C_Container.GetContainerNumSlots, bag)
        for slot = 1, (okN and number(slots)) or 0 do
            local ok, info = pcall(C_Container.GetContainerItemInfo, bag, slot)
            if ok and type(info) == "table" and not isSecret(info.itemID) and info.itemID == shard then
                list[#list + 1] = { bag = bag, slot = slot, soul = soul, count = number(info.stackCount) or 1 }
            end
        end
    end
    return list
end

function Warlock.CountShards()
    local total = 0
    for _, s in ipairs(Warlock.ShardSlots()) do total = total + s.count end
    return total
end

-- Restrictions ---------------------------------------------------------------

-- True when the client refuses AddOn item moves and deletion: combat, an affecting-combat answer that
-- is unreadable, or a Combat/Encounter/ChallengeMode/PvPMatch/Map AddOn restriction (Forever, dungeons).
local RESTRICTIONS = { "Combat", "Encounter", "ChallengeMode", "PvPMatch", "Map" }
function Warlock.MoveRestricted()
    if InCombatLockdown() then return true end
    if UnitAffectingCombat then
        local ok, affecting = pcall(UnitAffectingCombat, "player")
        if not ok or isSecret(affecting) or affecting then return true end
    end
    local kinds = type(Enum) == "table" and Enum.AddOnRestrictionType
    if type(C_RestrictedActions) ~= "table" or type(C_RestrictedActions.IsAddOnRestrictionActive) ~= "function"
        or type(kinds) ~= "table" then
        return false
    end
    for _, name in ipairs(RESTRICTIONS) do
        if kinds[name] ~= nil then
            local ok, active = pcall(C_RestrictedActions.IsAddOnRestrictionActive, kinds[name])
            if not ok or isSecret(active) or active == true then return true end
        end
    end
    return false
end

-- Player buff ------------------------------------------------------------------

-- First of `names` the player has as a buff: { readable, present, name, expires, duration }.
-- readable=false in combat (aura data is secret) or when the read fails; callers keep their last answer.
function Warlock.PlayerBuff(names)
    if InCombatLockdown() or not (C_UnitAuras and C_UnitAuras.GetAuraDataBySpellName) then
        return { readable = false }
    end
    for _, name in ipairs(names) do
        local ok, data = pcall(C_UnitAuras.GetAuraDataBySpellName, "player", name, "HELPFUL")
        if not ok or isSecret(data) then return { readable = false } end
        if type(data) == "table" then
            local expires = number(data.expirationTime)
            return {
                readable = true, present = true, name = name,
                expires = (expires and expires > 0) and expires or nil,
                duration = number(data.duration),
            }
        end
    end
    return { readable = true, present = false }
end

-- Trade ----------------------------------------------------------------------------

-- Name and level of a friendly player target other than you, or nil.
function Warlock.FriendlyTarget()
    local ok, valid = pcall(function()
        return UnitExists("target") and UnitIsPlayer("target") and not UnitIsUnit("target", "player")
            and UnitIsFriend("player", "target")
    end)
    if not ok or isSecret(valid) or not valid then return nil end
    local level = number(UnitLevel("target"))
    local name = UnitName("target")
    if not level or level < 1 or isSecret(name) or type(name) ~= "string" then return nil end
    return name, level
end

function Warlock.InitiateTrade()
    if not InitiateTrade then return false end
    return pcall(InitiateTrade, "target")
end

local function findItem(itemID)
    for bag = 0, lastBag() do
        local okN, slots = pcall(C_Container.GetContainerNumSlots, bag)
        for slot = 1, (okN and number(slots)) or 0 do
            local ok, info = pcall(C_Container.GetContainerItemInfo, bag, slot)
            if ok and type(info) == "table" and not isSecret(info.itemID) and info.itemID == itemID and not info.isLocked then
                return bag, slot
            end
        end
    end
end

local function freeTradeSlot()
    for slot = 1, 6 do
        if not GetTradePlayerItemLink(slot) then return slot end
    end
end

-- Put one Healthstone into the open trade window. Returns true, or false + reason ("restricted",
-- "no stone", "no slot", "refused") so the caller can tell the player what to do by hand. Never
-- presses Trade.
function Warlock.PlaceInTrade(itemID)
    if Warlock.MoveRestricted() then return false, "restricted" end
    if GetCursorInfo() then return false, "refused" end
    local bag, slot = findItem(itemID)
    local tradeSlot = freeTradeSlot()
    if not bag then return false, "no stone" end
    if not tradeSlot then return false, "no slot" end
    C_Container.PickupContainerItem(bag, slot)
    local kind, id = GetCursorInfo()
    if kind ~= "item" or id ~= itemID then
        ClearCursor()
        return false, "refused"
    end
    ClickTradeButton(tradeSlot)
    if GetCursorInfo() then
        ClearCursor()
        return false, "refused"
    end
    return true
end

-- Delete (always confirmed by the player) ----------------------------------------------

-- Pick the shard up and hand it to Blizzard's delete confirmation; its Delete button runs the
-- protected call and its Cancel returns the item to the bag. Returns true, or false + reason.
-- Only ever acts on a Soul Shard, and never when restricted or the cursor is busy.
function Warlock.ConfirmDeleteShard(bag, slot)
    if Warlock.MoveRestricted() then return false, "restricted" end
    if GetCursorInfo() then return false, "cursor busy" end
    if not (StaticPopup_Show and StaticPopupDialogs and StaticPopupDialogs["DELETE_ITEM"]) then return false, "no dialog" end
    C_Container.PickupContainerItem(bag, slot)
    local kind, id, link = GetCursorInfo()
    if kind ~= "item" or id ~= HMF.Services.Supplies.SHARD_ITEM then
        ClearCursor()
        return false, "refused"
    end
    StaticPopup_Show("DELETE_ITEM", link or "")
    return true
end
